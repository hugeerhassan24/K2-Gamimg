# K2 Gaming — PS4 Exploit Host

K2 Gaming is a branded front end for the supplied upstream PS4 host source.

## Supported host routes in this source package

- 5.05 — `505/`
- 6.72 GoldHEN — `672goldhen/`
- 6.72 — `672/`
- 9.00 GoldHEN — `900goldhen/`
- 9.00 — `900v3/`
- Multi-firmware host — `g2all/`

The upstream README lists firmware families `5.05`, `6.72`, `7.XX`, `8.XX`, `9.XX`, `10.XX`, `11.XX`, `12.XX`, `13.XX`, and `14.00`. This is an upstream compatibility claim, not independent verification of every minor firmware release. In particular, do not assume that every version number between 5.05 and 13.52 has been tested.

## Deploy to Netlify

1. Extract this ZIP.
2. Upload the **contents** of this folder (the `index.html`, `style.css`, `img.jpg`, and firmware folders) as the site publish directory.
3. Keep the directory structure unchanged.
4. Open the HTTPS site and select the correct firmware host.
5. On a compatible PS4 browser, open the chosen host while online and wait for its cache/install message to finish before trying offline use.

## Important offline note

This source uses legacy HTML Application Cache manifests (`*.manifest`). The new K2 homepage does not claim that offline mode is complete merely because the homepage loads. Browser support, manifest MIME handling, cache completion, and offline launch must be tested on the target PS4 browser. The Netlify `_headers` file sets the manifest MIME type, but cannot guarantee PS4-side caching behavior.

## Upstream attribution and rights

The host code and payload resources were supplied from the public repository:
https://github.com/GamerHack/GamerHack.github.io

The original upstream developer attribution is retained in the relevant source pages. This package does not claim authorship of the exploit code or payloads. No explicit license file was present in the downloaded repository archive; obtain the upstream author's permission or confirm applicable rights before publicly redistributing a modified copy.

## K2 Gaming branding

The root landing page and shared background use the K2 Gaming branding and the background image supplied by the site owner. Existing firmware directories, scripts, payload binaries, and manifest paths have been retained rather than rewritten.
